<?php

error_reporting(E_ERROR | E_PARSE);

$data_inis = date("Y-m-d");  //hoje
$data_fins = date('Y-m-d', strtotime('-1 week'));

$sql_tec = "
SELECT DATE_FORMAT(date, '%b-%d') as data, COUNT(id) as conta
FROM glpi_tickets
WHERE glpi_tickets.is_deleted = 0
AND glpi_tickets.date BETWEEN '" . $data_fins ." 00:00:00' AND '".$data_inis." 23:59:59'
GROUP BY data
ORDER BY data DESC
";

$query_tec = $DB->query($sql_tec);

echo "<script type='text/javascript'>

$(function () {
        $('#graf1').highcharts({
            chart: {
                type: 'column'                
            },
            title: {
                text: 'Chamados dos últimos 7 dias'
            },
            subtitle: {
                text: ''
            },
            xAxis: { 
            categories: ";

				$categories = array();
				while ($entity = $DB->fetchAssoc($query_tec)) {
				    $categories[] = $entity['data'];
				}   
				echo json_encode($categories);
				
				//zerar rows para segundo while
				
				$DB->dataSeek($query_tec, 0) ;               
				
				echo ",
                title: {
                    text: ''
                },
                labels: {
                	style: {
                        fontSize: '12px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                column: {
                    dataLabels: {
                        enabled: true,                                                
                    },
                     borderWidth: 2,
                	borderColor: 'white',
                	shadow:true,           
                	showInLegend: false
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -40,
                y: 100,
                floating: true,
                borderWidth: 1,
                backgroundColor: '#FFFFFF',
                shadow: true,
                enabled: false
            },
            credits: {
                enabled: false
            },
            series: [{            	
            	                 dataLabels: {
                    enabled: true,                    
                    color: '#000099',
                    style: {
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                },
                name: '". $LANG['plugin_dashboard']['1']."',
                data: [ ";
   
					$DB->dataSeek($query_tec, 0) ;     
					             
					while ($entity = $DB->fetchAssoc($query_tec)) {
						echo $entity['conta'].",";
					}    
					
					echo "]
            }]
        });
    });

</script>
";
		
		?>
